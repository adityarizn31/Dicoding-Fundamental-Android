package com.dicoding.githubproyekaditya.data.model

data class UserResponse(
    val items : ArrayList<User>
)
